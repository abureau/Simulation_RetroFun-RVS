setGeneric("RVsharing", function(data, dad.id, mom.id,carriers) standardGeneric("RVsharing"))
setGeneric("GeneDrop", function(trio, geno.vec ) standardGeneric("GeneDrop"))
setGeneric("ComputeKinshipPropCoef", function(obj ) standardGeneric("ComputeKinshipPropCoef"))